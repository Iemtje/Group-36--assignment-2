# Report for Assignment 1

## Project

Description: Password Generator Application - A comprehensive tool for generating secure passwords with various customization options including length, character types, and security requirements.
The Password Generator Application is a powerful and flexible Python-based tool designed to create highly secure and customizable passwords. It offers users full control over the structure and strength of their passwords, making it suitable for both personal use and professional security needs.

Key elements: 
- Custom Length: Generate passwords of any desired length to meet varying security policies.
- Character Type Selection: Choose which character sets to include:
- Uppercase letters (A–Z)
- Lowercase letters (a–z)
- Digits (0–9)
- Special characters (e.g., !@#$%^&*)
- Enhanced Readability: Option to exclude visually similar characters (such as 0, O, 1, l, I) to reduce confusion and improve usability.
- Security Enforcement: Ensures that at least one character from each selected category is included, preventing weak or predictable passwords.
- Randomization: Characters are randomly selected and shuffled to avoid recognizable patterns, increasing resistance against brute-force or dictionary attacks.

Programming language: Python

 ---

## Usage

The package exposes password generation and signup utilities through the `src` package.

### Signup Utilities

```python
from src import run_signup_process, load_existing_users

users = load_existing_users()
run_signup_process(users)
```

### Standalone Password Generation

To generate a password with custom options:

```python
from src.password_utils import generate_password, get_character_pool, get_required_sets

# Example: include uppercase, lowercase, digits, and special characters; do not exclude similar characters
pool = get_character_pool(
    include_uppercase=True,
    include_lowercase=True,
    include_digits=True,
    include_special=True,
    exclude_similar=False
)
required_sets = get_required_sets(
    include_uppercase=True,
    include_lowercase=True,
    include_digits=True,
    include_special=True,
    exclude_similar=False
)
password = generate_password(length=16, pool=pool, required_sets=required_sets)
print(password)
```

---

## Running Tests

Install `pytest` if not already installed and run:

```bash
python -m pytest -q
```

---

## Notes

- Ensure your working directory is set to the project root when running scripts or tests.
- If you encounter import errors, you may need to add the `src` directory to your `PYTHONPATH`:
  ```bash
  export PYTHONPATH=$PYTHONPATH:./src
  ``` 
